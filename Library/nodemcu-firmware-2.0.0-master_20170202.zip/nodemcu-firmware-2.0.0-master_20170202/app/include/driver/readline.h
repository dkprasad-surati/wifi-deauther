#ifndef READLINE_APP_H
#define READLINE_APP_H

bool uart_getc(char *c);

#endif /* READLINE_APP_H */
