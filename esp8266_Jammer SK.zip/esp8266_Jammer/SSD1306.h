
#ifndef SSD1306_h
#define SSD1306_h
#include "SSD1306Wire.h"

// For legacy support make SSD1306 an alias for SSD1306
typedef SSD1306Wire SSD1306;


#endif
